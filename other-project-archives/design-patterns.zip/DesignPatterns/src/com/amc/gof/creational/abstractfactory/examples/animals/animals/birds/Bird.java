/**
 * 
 */
package com.amc.gof.creational.abstractfactory.examples.animals.animals.birds;

import com.amc.gof.creational.abstractfactory.examples.animals.animals.Animal;

/**
 * @author 109365
 *
 */
public interface Bird extends Animal{
	public static final String ALBATROSS="Albatross";
	public static final String PEGION="Pegion";
}
