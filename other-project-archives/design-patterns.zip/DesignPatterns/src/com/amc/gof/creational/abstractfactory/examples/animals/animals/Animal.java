/**
 * 
 */
package com.amc.gof.creational.abstractfactory.examples.animals.animals;


/**
 * @author 109365
 *
 */
public interface Animal {
	public String name();
}
