/**
 * 
 */
package com.amc.gof.creational.factory;

/**
 * @author Amitava Chakraborty
 * Nov 2, 2002 
 */
public interface Shape {
   void draw();
}

