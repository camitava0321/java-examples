/**
 * 
 */
package com.amc.gof.creational.abstractfactory.examples.animals.animals.birds;

/**
 * @author 109365
 *
 */
public class Albatross implements Bird{

	public String name() {
		// TODO Auto-generated method stub
		return Bird.ALBATROSS;
	}
	
	
}
