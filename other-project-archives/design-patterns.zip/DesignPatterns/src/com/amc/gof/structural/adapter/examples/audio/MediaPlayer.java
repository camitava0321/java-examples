/**
 * 
 */
package com.amc.gof.structural.adapter.examples.audio;

/**
 * @author Amitava Chakraborty
 * Aug 23, 2002 
 */
public interface MediaPlayer {
	   public void play(String audioType, String fileName);
}