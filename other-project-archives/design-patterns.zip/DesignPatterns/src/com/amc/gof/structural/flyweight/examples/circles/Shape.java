/**
 * 
 */
package com.amc.gof.structural.flyweight.examples.circles;
/**
 * @author Amitava Chakraborty
 * May 1, 2002 
 */
public interface Shape {
	   void draw();
	}