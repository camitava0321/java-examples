/**
 * 
 */
package com.amc.gof.structural.proxy.examples.image;

/**
 * @author Amitava Chakraborty
 * Aug 11, 2002 
 */
public interface Image {
	   void display();
}