/**
 * 
 */
package com.amc.gof.structural.adapter.examples.audio;

/**
 * @author Amitava Chakraborty
 * Aug 23, 2002 
 */
public interface AdvancedMediaPlayer {	
	   public void playVlc(String fileName);
	   public void playMp4(String fileName);
}