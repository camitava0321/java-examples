/**
 * 
 */
package com.amc.gof.structural.facade;

/**
 * @author Amitava Chakraborty
 * Nov 2, 2002 
 */

public interface Shape {
   void draw();
}

