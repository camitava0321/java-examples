package com.amc.gof.structural.flyweight.examples.tea;
/**
 * @author Amitava Chakraborty
 * May 1, 2002 
*/

public abstract class TeaOrder {  
    public abstract void serveTea(TeaOrderContext teaOrderContext);
}
