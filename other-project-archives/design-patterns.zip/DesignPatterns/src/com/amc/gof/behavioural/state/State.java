/**
 * 
 */
package com.amc.gof.behavioural.state;

/**
 * @author Amitava Chakraborty
 * Nov 2, 2002 
 */
public interface State {
	   public void doAction(Context context);
}
