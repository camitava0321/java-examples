/**
 * 
 */
package com.amc.gof.behavioural.interpreter.examples.expression;

/**
 * @author Amitava Chakraborty
 * Nov 2, 2002 
 */
public interface Expression {
   public boolean interpret(String context);
}