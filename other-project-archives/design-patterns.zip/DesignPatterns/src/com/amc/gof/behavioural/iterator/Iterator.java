/**
 * 
 */
package com.amc.gof.behavioural.iterator;

/**
 * @author Amitava Chakraborty
 * Nov 2, 2002 
 */
public interface Iterator {
	   public boolean hasNext();
	   public Object next();
	}