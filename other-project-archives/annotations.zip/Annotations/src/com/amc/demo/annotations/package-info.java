@com.amc.demo.annotations.PackageAnnotation (description="The main package that holds the annotation class, as well as the usage of the annotations")
package com.amc.demo.annotations;
import com.amc.demo.annotations.PackageAnnotation;